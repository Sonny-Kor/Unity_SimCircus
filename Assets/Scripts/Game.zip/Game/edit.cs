using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class edit : MonoBehaviour
{
    private SpriteRenderer rend;

    // Update is called once per frame
    void Update()
    {
        
    }

    public void render()
    {
        rend = Selection.activeGameObject.GetComponent<SpriteRenderer>();
        rend.sortingLayerName = "front front front";

    }
}
