using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class action : MonoBehaviour
{
    public enum Type {Tiger, Bear, Chimpanze, Dog, Elephant, Horse, lion };
    public Type type;
    public Animator anim;
    public Player change;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        anim.SetBool("Bool", false);
    }

    // Update is called once per frame
    void Update()
    {
    }

    public void moving()
    {
        Invoke("animstart", 1);
    }

    public void stop()
    {
        Invoke("animstop", 3);
    }

    void animstop()
    {
        anim.SetBool("Bool", false);
        gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "middle";
    }

    public void animstart()
    {
        Debug.Log("here");
        anim.SetBool("Bool", true);
    }
}
